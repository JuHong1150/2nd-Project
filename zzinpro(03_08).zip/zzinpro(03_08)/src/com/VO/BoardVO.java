package com.VO;

public class BoardVO {
private String id;
private String title;
private int category;
private String YMD;
public BoardVO(String id, String title, int category, String yMD) {
	super();
	this.id = id;
	this.title = title;
	this.category = category;
	YMD = yMD;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getCategory() {
	return category;
}
public void setCategory(int category) {
	this.category = category;
}
public String getYMD() {
	return YMD;
}
public void setYMD(String yMD) {
	YMD = yMD;
}


}
