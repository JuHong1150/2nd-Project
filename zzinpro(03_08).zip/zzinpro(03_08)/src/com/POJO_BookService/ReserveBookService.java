package com.POJO_BookService;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.BookDAO;
import com.Inter.Command;
import com.VO.MemberVO;


public class ReserveBookService implements Command {
	
	public String excute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(); 
		
		MemberVO vo = (MemberVO)session.getAttribute("vo");
		String isbn = (String)session.getAttribute("reserve-book-isbn");
		
		String userId = vo.getId();
		// System.out.println("DeleteAllMessageService�� passed in �� email ��: " + email);
		
		String bookLoanDate = request.getParameter("book-loan-date");
		String libCode = request.getParameter("smart-lib-list"); 
		System.out.println("userId�� input value -->> " + userId);
		System.out.println("bookLoanDate�� input value -->> " + bookLoanDate);
		System.out.println("libCode�� input value -->> " + libCode);
		
		BookDAO dao = new BookDAO();
		int cnt = dao.reserveBook(libCode, isbn, "1", userId, bookLoanDate);
//		reserveBook(String p_lib_cd, String p_isbn, String p_mng_no, String p_id, String p_loan_hope_ymd)
		return "Main.jsp";
	}
}
