package com.VO;

public class BookReservationVO {

	// DB Table
	// LIB_CD	ISBN	MNG_NO	ID	RESERVE_YMD	RESERVE_SEQ	LOAN_HOPE_YMD
	// sb0001	9791187119845	1	17@naver.com	2021-03-03	1	2021-03-19
	
	private String libCd;
	private String isbn;
	private String mngNo;
	private String userId;
	private String reserveDate;
	private String reserveSeq;
	private String loanHopeDate;
	
	public BookReservationVO(String libCd, String isbn, String mngNo, String userId, String reserveDate, String reserveSeq, String loanHopeDate) {
		super();
		this.libCd = libCd;
		this.isbn = isbn;
		this.mngNo = mngNo;
		this.userId = userId;
		this.reserveDate = reserveDate;
		this.reserveSeq = reserveSeq;
		this.loanHopeDate = loanHopeDate;
	}

	public String getLibCd() {
		return libCd;
	}

	public void setLibCd(String libCd) {
		this.libCd = libCd;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getMngNo() {
		return mngNo;
	}

	public void setMngNo(String mngNo) {
		this.mngNo = mngNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getReserveDate() {
		return reserveDate;
	}

	public void setReserveDate(String reserveDate) {
		this.reserveDate = reserveDate;
	}

	public String getReserveSeq() {
		return reserveSeq;
	}

	public void setReserveSeq(String reserveSeq) {
		this.reserveSeq = reserveSeq;
	}

	public String getLoanHopeDate() {
		return loanHopeDate;
	}

	public void setLoanHopeDate(String loanHopeDate) {
		this.loanHopeDate = loanHopeDate;
	}
}
