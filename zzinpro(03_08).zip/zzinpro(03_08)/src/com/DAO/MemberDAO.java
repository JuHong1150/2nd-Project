package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.VO.MemberVO;


public class MemberDAO {
	
	Connection conn = null;
	PreparedStatement psmt =null;
	ResultSet rs = null;
	int cnt =0;
	MemberVO vo = null;

	public Connection getConn() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
            		+ "database=SMARTLIB;user=importking;password=12345";
             conn = DriverManager.getConnection(connectionUrl);
            Statement stmt = conn.createStatement();

        } catch (Exception e) {
            System.out.println("SQLException : " + e);
        }
		return conn;
	}
	
	public void close() {
		//conn,psmt,rs 
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(psmt!=null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public int Join(String name, String gender, String id, String passwords, String favorite, String birth) {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
            		+ "database=SMARTLIB;user=importking;password=12345";
            Connection conn = DriverManager.getConnection(connectionUrl);
            Statement stmt = conn.createStatement();
            


			String sql = "insert into MEMBER values(?, ?,null,?,?,?,?)";
			PreparedStatement psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, name);
			psmt.setString(2, gender);
			psmt.setString(3, id);
			psmt.setString(4, passwords);
			psmt.setString(5, favorite);
			psmt.setString(6, birth);

			
			 cnt = psmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return cnt;
	}
	
	public MemberVO Login(String id, String pw) {
		
		MemberVO vo = null;
		
		try {
			
			System.out.println("");
			getConn();
            
			String sql = "SELECT * FROM MEMBER WHERE ID = ? and PASSWORDS = ?";
			
			PreparedStatement psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id);
			psmt.setString(2, pw);
			
			ResultSet rs = psmt.executeQuery();
			
			if(rs.next()) {
				String get_name = rs.getString(1);
				String get_gender = rs.getString(2);
				String get_age = rs.getString(3);
				String get_id = rs.getString(4);
				String get_favorite = rs.getString(6);
				String get_birth = rs.getString(7);
				
				System.out.println("MemberDAO get_id ->" + get_id);
				
				 vo = new MemberVO(get_name, get_gender, get_id, get_age, get_favorite, get_birth);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return vo;
	}
	
	
	public ArrayList<MemberVO> search() {
		
		MemberVO vo = null;
		ArrayList<MemberVO> arr = new ArrayList<MemberVO>();
		String book_name = "";
		try {
			
			getConn();
			
			System.out.println(book_name);
			
			String sql = "select * from BOOK where BOOK_NAME = ? ";

			PreparedStatement psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, book_name);
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				String b_name = rs.getString(1);
				String author = rs.getString(2);
				String publisher = rs.getString(3); 
				String isbn = rs.getString(6);
				String libname = rs.getString(8);
				
				vo = new MemberVO(b_name, author, publisher, isbn, libname);
				arr.add(vo);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return arr;
	}
	
	
	public boolean IdCheck(String id) {
		boolean check = true;
		try {
			getConn();
			String sql = "SELECT * FROM MEMBER WHERE ID = ? ";
			PreparedStatement psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			ResultSet rs = psmt.executeQuery();
		
			if (rs.next()) { 
				check = false;
			}else {
				check = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return check;
	}
	
	
	
	
	
}
