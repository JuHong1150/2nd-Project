package com.POJO_BookService;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.SickDAO;
import com.Inter.Command;
import com.VO.SickVO;



public class RegisterSickness implements Command {

	public String excute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("ȸ�����Ա���� �����ϰڽ��ϴ�.");
		
		 request.setCharacterEncoding("UTF-8");
		String mng_num = request.getParameter("mng_num");
		String sick_category = request.getParameter("sick_category");
		String sick_degree = request.getParameter("sick_degree");
		String sick_reg_date = request.getParameter("sick_reg_date");
		String sick_reg_id = request.getParameter("sick_reg_id");
		String isbn = request.getParameter("isbn");
		String libcd = request.getParameter("libcd");
		String content = request.getParameter("content");
		

		// 2. JDBC�� �̿��ؼ� ����ڰ� �Է��� 4���� ���� message_memeber ���̺��� �����Ͻÿ�

		SickDAO dao = new SickDAO();
		int cnt = dao.register(mng_num, sick_category,sick_degree, sick_reg_date, sick_reg_id,isbn,libcd, content );

		//HttpSession session = request.getSession();
		//SickVO vo = new SickVO(mng_num, sick_category,sick_degree, sick_reg_date, sick_reg_id,isbn,libcd, content);

		//request.setAttribute("SickVO", vo);
		
		if(cnt>0) {
			HttpSession session = request.getSession();
			SickVO vo = new SickVO(mng_num, sick_category,sick_degree, sick_reg_date, sick_reg_id,isbn,libcd, content);

			request.setAttribute("SickVO", vo);
			
		}else{
			System.out.println("�����......NOPE!...");
		}
		
		return "Main.jsp";
	}
	
	
}
