package com.POJO_MemService;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.MemberDAO;
import com.Inter.Command;
import com.VO.MemberVO;

public class JoinService1 implements Command {
	
	public String execute(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		System.out.println("ȸ�����Ա���� �����ϰڽ��ϴ�");
		request.setCharacterEncoding("euc-kr");

		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String passwords = request.getParameter("pw");
		String phone = request.getParameter("tel");
		String gender = request.getParameter("demo-priority");
		String birth = request.getParameter("birth");
		String favorite = request.getParameter("demo-category");
		

		MemberDAO dao = new MemberDAO();//��ü����
		
		int cnt = dao.Join(name, gender, id, passwords, favorite, birth);


			HttpSession session = request.getSession();
			MemberVO vo = new MemberVO(name, gender, id, passwords, favorite, birth);
			
			request.setAttribute("join_vo", vo);

			return "Main.jsp";
			
	}

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		return null;
	}
}
	
