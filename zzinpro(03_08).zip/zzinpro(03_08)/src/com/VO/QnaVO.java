package com.VO;

public class QnaVO {

	private String id;
	private String title;
	private int YMD;
	private String context;
	public QnaVO(String id, String title, int yMD, String context) {
		super();
		this.id = id;
		this.title = title;
		YMD = yMD;
		this.context = context;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getYMD() {
		return YMD;
	}
	public void setYMD(int yMD) {
		YMD = yMD;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	
	
}
