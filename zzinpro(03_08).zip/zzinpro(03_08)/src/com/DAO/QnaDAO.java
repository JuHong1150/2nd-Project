package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.VO.QnaVO;



public class QnaDAO {
	Connection conn = null;
	PreparedStatement psmt =null;
	ResultSet rs = null;
	int cnt =0;
	QnaVO vo = null;
public Connection getConn() {
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
            		+ "database=SMARTLIB;user=importking;password=12345";
             conn = DriverManager.getConnection(connectionUrl);
            Statement stmt = conn.createStatement();

        } catch (Exception e) {
            System.out.println("SQLException : " + e);
        }
		return conn;
	}
	
	public void close() {
		//conn,psmt,rs 
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(psmt!=null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}public int insert(String id,String title,int category,String context) {
		try {
			Connection conn = getConn();
			System.out.println("으아아아아");
			String sql="insert into USER_BOARD values(?,?,?,sysdatetime(),?)";
			PreparedStatement psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id);
			psmt.setString(2, title);
			psmt.setInt(3, category);
			psmt.setString(4, context);
			
			 cnt = psmt.executeUpdate();
			System.out.println("왜안되냥");
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}return cnt;
	}
}
