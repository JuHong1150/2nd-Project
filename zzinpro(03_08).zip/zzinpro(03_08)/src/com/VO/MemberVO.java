package com.VO;

public class MemberVO {

	public MemberVO(String b_name, String author, String publisher, String isbn, String libname) {
		super();
		this.b_name = b_name;
		this.author = author;
		this.publisher = publisher;
		this.isbn = isbn;
		this.libname = libname;
	}
	private String b_name;
	private String author;
	private String publisher;
	private String isbn;
	private String libname;

	public String getB_name() {
		return b_name;
	}


	public void setB_name(String b_name) {
		this.b_name = b_name;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getPublisher() {
		return publisher;
	}


	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}


	public String getIsbn() {
		return isbn;
	}


	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}


	public String getLibname() {
		return libname;
	}


	public void setLibname(String libname) {
		this.libname = libname;
	}


	public MemberVO(String name, String gender, String id, String passwords, String favorite, String birth) {
		super();
		this.name = name;
		this.gender = gender;
		this.id = id;
		this.passwords = passwords;
		this.favorite = favorite;
		this.birth = birth;
	}
	
	
	public MemberVO(String get_id, String get_favorite, String get_birth) {
		// TODO Auto-generated constructor stub
		// �̰� �� ������� �� �����غ��� 21.02.28
	}


	public MemberVO(String id, String passwords) {
		// TODO Auto-generated constructor stub
		this.id = id;
		this.passwords = passwords;
	}





	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPasswords() {
		return passwords;
	}
	public void setPasswords(String passwords) {
		this.passwords = passwords;
	}
	public String getFavorite() {
		return favorite;
	}
	public void setFavorite(String favorite) {
		this.favorite = favorite;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	private String name;
	private String gender;
	private String id;
	private String passwords;
	private String favorite;
	private String birth;
	
	
	
}
