package com.VO;

public class LoanVO {
	
	private String bookImgUrl;
	private String bookName;
	private String isbn;
	private String libcode;
	
	public LoanVO(String bookImgUrl, String bookName, String isbn, String libcode) {
		super();
		this.bookImgUrl = bookImgUrl;
		this.bookName = bookName;
		this.isbn = isbn;
		this.libcode = libcode;
	}

	public String getBookImgUrl() {
		return bookImgUrl;
	}

	public void setBookImgUrl(String bookImgUrl) {
		this.bookImgUrl = bookImgUrl;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getLibcode() {
		return libcode;
	}

	public void setLibcode(String libcode) {
		this.libcode = libcode;
	}
	
	
}
