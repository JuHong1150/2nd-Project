package com.POJO_BookService;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.QnaDAO;


@WebServlet("/Qna")
public class Qna extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("demo-name");
		String title = request.getParameter("demo-email");
		int category = Integer.parseInt(request.getParameter("demo-category"));
		String context = request.getParameter("demo-message");
		
		System.out.println("QnaDAO 이전");
		QnaDAO dao = new QnaDAO();
		System.out.println("QnaDAO 이후");
		int cnt = dao.insert(id, title, category, context);
		
		if(cnt>0) {
			System.out.println("12334");
			
			response.sendRedirect("board.jsp");
		}else {
			System.out.println("12345");
			
		}
	}

}
