package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.VO.BookVO;

public class BookDAO {

   private PreparedStatement psmt = null;
   private ResultSet rs = null;
   private Connection conn = null;
   
   private int cnt = 0;
   private BookVO vo = null;
   
   public Connection getConn() {
      
      Connection conn = null;
      
      try {
         
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
                  + "database=SMARTLIB;user=importking;password=12345";
            //String connectionUrl = "jdbc:sqlserver://localhost;database=SMARTLIB;integratedSecurity=true";
            conn = DriverManager.getConnection(connectionUrl);
            Statement stmt = conn.createStatement();
            System.out.println("BookDAO getConn() �떎�뻾 �셿猷� -> MS-SQL �젒�냽 �셿猷�");
      
      } catch (Exception e) {
         e.printStackTrace();
      }
      
      return conn;
   }
   
   public void close() {
      
      if (rs != null) {
         try {
            rs.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
      
      if (psmt != null) {
         try {
            psmt.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
      
      if (conn != null) {
         try {
            conn.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
   }
   
   
   public ArrayList<BookVO> selectBook(String p_bookname) {
      ArrayList<BookVO> arr = new ArrayList<BookVO>();
      
      System.out.println("BookDAO�쓽 selectBook method�쓽 bookName input�� ==>>" + p_bookname);
      try {
         
         Connection conn = getConn();

         String sql = "SELECT    LIBCD\r\n" + 
               "      , ISBN\r\n" + 
               "      , BOOK_NAME\r\n" + 
               "      , AUTHOR\r\n" + 
               "      , PUBLISHER\r\n" + 
               "      , BOOK_IMG_URL\r\n" + 
               "      , VIEW_ORDER      = ROW_NUMBER() OVER(ORDER BY BOOK_NAME_LENGTH_DIFF)\r\n" + 
               "FROM\r\n" + 
               "(\r\n" + 
               "   SELECT    A.LIBCD\r\n" + 
               "         , A.ISBN\r\n" + 
               "         , A.BOOK_NAME\r\n" + 
               "         , A.AUTHOR\r\n" + 
               "         , A.PUBLISHER\r\n" + 
               "         , B.BOOK_IMG_URL\r\n" + 
               "         , A.BOOK_NAME_LENGTH_DIFF\r\n" + 
               "   FROM\r\n" + 
               "   (\r\n" + 
               "      SELECT    BOOK_NAME\r\n" + 
               "            , AUTHOR\r\n" + 
               "            , PUBLISHER\r\n" + 
               "            , ISBN\r\n" + 
               "            , BOOK_NAME_LENGTH_DIFF = LEN(BOOK_NAME) - LEN(?)\r\n" + 
               "            , LIBCD\r\n" + 
               "      FROM BOOK\r\n" + 
               "      WHERE 1=1\r\n" + 
               "         AND BOOK_NAME      LIKE ? \r\n" + 
               "         AND LIBCD         = '124003'\r\n" + 
               "   ) A\r\n" + 
               "   INNER JOIN BOOK_IMAGE      AS B\r\n" + 
               "   ON 1=1\r\n" + 
               "      AND A.ISBN = B.ISBN\r\n" + 
               "   WHERE 1=1\r\n" + 
               "      AND BOOK_NAME_LENGTH_DIFF <= 5   \r\n" + 
               ") A\r\n" + 
               "WHERE 1=1";

         psmt = conn.prepareStatement(sql);
         psmt.setString(1, p_bookname);
         psmt.setString(2, "%" + p_bookname + "%");
         
         rs = psmt.executeQuery();
      
         while(rs.next()) {
            
            String libCode = rs.getString(1);
            String isbn = rs.getString(2);
            String bookName = rs.getString(3);
            String author = rs.getString(4);
            String publisher = rs.getString(5);
            String bookImgUrl = rs.getString(6);
            
            vo = new BookVO(libCode, isbn, bookName, author, publisher, bookImgUrl);
            arr.add(vo);
         }
         
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         System.out.println("BookDAO selectBook method �룄�꽌寃��깋寃곌낵(沅�): " + arr.size());
         close();
      }
      
      return arr;
   }
   
   
   public ArrayList<BookVO> selectBookByIsbn(String p_isbn) {
      ArrayList<BookVO> arr = new ArrayList<BookVO>();
      
      System.out.println("BookDAO�쓽 selectBook method�쓽 bookName input�� ==>>" + p_isbn);
      try {
         
         Connection conn = getConn();

         String sql = "SELECT    A.ISBN\r\n" + 
               "      , A.BOOK_NAME\r\n" + 
               "      , A.AUTHOR\r\n" + 
               "      , A.PUBLISHER\r\n" + 
               "      , BOOK_GENRE      = B.KDC_B_NM + '//' + B.KDC_M_NM\r\n" + 
               "      , C.BOOK_IMG_URL\r\n" + 
               "FROM\r\n" + 
               "(   -- 梨� �젙蹂�(�룞�씪 梨낆씠 �뿬�윭�룄�꽌愿��뿉 �엳�쑝�땲 TOP 1�븿)\r\n" + 
               "   SELECT TOP 1 *\r\n" + 
               "   FROM BOOK\r\n" + 
               "   WHERE 1=1\r\n" + 
               "      AND ISBN = ?\r\n" + 
               ") A\r\n" + 
               "LEFT JOIN GENRE         AS B\r\n" + 
               "ON 1=1\r\n" + 
               "   AND SUBSTRING(A.GENRE,1,2) + '0' = B.KDC_M_CD\r\n" + 
               "LEFT JOIN BOOK_IMAGE   AS C\r\n" + 
               "ON 1=1\r\n" + 
               "   AND A.ISBN      = C.ISBN";
         
         psmt = conn.prepareStatement(sql);
         psmt.setString(1, p_isbn);
         
         rs = psmt.executeQuery();
      
         while(rs.next()) {
            
            String isbn = rs.getString(1);
            String bookName = rs.getString(2);
            String author = rs.getString(3);
            String publisher = rs.getString(4);
            String bookGenre = rs.getString(5);
            String bookImgUrl = rs.getString(6);
            
            vo = new BookVO(null, isbn, bookName, author, publisher, bookImgUrl, bookGenre);
            arr.add(vo);
         }
         
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         System.out.println("BookDAO selectBookByIsbn method �룄�꽌寃��깋寃곌낵(沅�): " + arr.size());
         close();
      }
      
      return arr;
   }
   
   public ArrayList<BookVO> Rec() {
      ArrayList<BookVO> arr = new ArrayList<BookVO>();

      String isbn = null;
      String bookImgUrl = null;

      try {

         Connection conn = getConn();

         String sql = "SELECT TOP 30\r\n" + 
               "        AGE_CD\r\n" + 
               "      , GENDER_CD\r\n" + 
               "      , ISBN\r\n" + 
               "      , KDC_CD\r\n" + 
               "      , KDC_CD_B\r\n" + 
               "      , KDC_CD_M\r\n" + 
               "      , BOOK_IMG_URL\r\n" + 
               "      , LOAN_CNT_SUM = SUM(CONVERT(INT, LOAN_CNT))\r\n" + 
               "FROM BOOK_RANKING_STAT WHERE AGE_NM != '誘몄긽' AND AGE_CD = '30' AND KDC_CD_M IS NOT NULL AND KDC_CD IS NOT NULL AND KDC_CD = '813.7'\r\n" + 
               "GROUP BY AGE_CD, GENDER_CD, KDC_CD, KDC_CD_B, KDC_CD_M, BOOK_IMG_URL, ISBN\r\n" + 
               "ORDER BY 8 DESC";

         psmt = conn.prepareStatement(sql);

         rs = psmt.executeQuery();

         while (rs.next()) {

            isbn = rs.getString(3);
            bookImgUrl = rs.getString(7);

            vo = new BookVO(isbn, bookImgUrl);
            arr.add(vo);
         }

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         System.out.println("BookDAO selectBook method �룄�꽌寃��깋寃곌낵(沅�): " + arr.size());
         close();
      }

      return arr;
   }
   
   public int reserveBook(String p_lib_cd, String p_isbn, String p_mng_no, String p_id, String p_loan_hope_ymd) {
      System.out.println("�룄�꽌�삁�빟 �떆�룄以묒엯�땲�떎.");
      int cnt = 0;
      
      Connection conn = getConn();
      
      try {
      
         String sql = "INSERT INTO MEMBER_BOOK_RESERVE\r\n" + 
               "         (LIB_CD   , ISBN   , MNG_NO   , ID   , RESERVE_YMD            , RESERVE_SEQ   , LOAN_HOPE_YMD)\r\n" + 
               "VALUES    (?      , ?      , ?         , ?      , CONVERT(DATE,GETDATE())   , ?            , ?)";
         
         psmt = conn.prepareStatement(sql);
         psmt.setString(1, p_lib_cd);            // LIB_CD
         psmt.setString(2, p_isbn);               // ISBN
         psmt.setString(3, p_mng_no);            // MNG_NO
         psmt.setString(4, p_id);               // ID
         psmt.setInt(5, 1);                     // RESERVE_SEQ
         psmt.setString(6, p_loan_hope_ymd);         // LOAN_HOPE_YMD
         
         cnt = psmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         System.out.println("reserveBook() method Done!! -->");
      }

      return cnt;
   }
   
   public ArrayList<BookVO> Rec1() {
      ArrayList<BookVO> arr1 = new ArrayList<BookVO>();

      String isbn = null;
      String bookImgUrl = null;

      try {

         Connection conn = getConn();

         String sql = "SELECT TOP 30\r\n" + "        AGE_NM\r\n" + "      , GENDER_NM\r\n" + "      , ISBN\r\n"
                 + "      , KDC_CD_M\r\n" + "      , BOOK_IMG_URL\r\n"
                 + "      , LOAN_CNT_SUM = SUM(CONVERT(INT, LOAN_CNT))\r\n"
                 + "FROM BOOK_RANKING_STAT WHERE AGE_NM != '미상'AND AGE_NM = '20대' AND GENDER_NM = '여성' AND KDC_CD_M IS NOT NULL\r\n"
                 + "GROUP BY AGE_NM, GENDER_NM, KDC_CD_M, BOOK_IMG_URL, ISBN\r\n" + "ORDER BY 6 DESC";

         psmt = conn.prepareStatement(sql);

         rs = psmt.executeQuery();

         while (rs.next()) {

            isbn = rs.getString(3);
            bookImgUrl = rs.getString(5);

            vo = new BookVO(isbn, bookImgUrl);
            arr1.add(vo);
         }

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         System.out.println("BookDAO selectBook method �룄�꽌寃��깋寃곌낵(沅�): " + arr1.size());
         close();
      }

      return arr1;
   }
   
   
}