package com.POJO_MemService;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.MemberDAO;

@WebServlet("/JoinService_JH")
public class JoinService_JH extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("demo-name1");
		String id = request.getParameter("id");
		String passwords = request.getParameter("pw");
		String phone = request.getParameter("tel");
		String gender = request.getParameter("demo-priority");
		String birth = request.getParameter("birth");
		String favorite = request.getParameter("demo-category");
		
		MemberDAO dao = new MemberDAO();
		int cnt = dao.Join(name, gender, id, passwords, favorite, birth);
		
			
			if (cnt > 0) {
				response.sendRedirect("Main.jsp");
			}

	}

}
