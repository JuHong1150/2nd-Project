package com.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.VO.SickVO;

public class SickDAO {

	PreparedStatement psmt = null;
	ResultSet rs = null;
	Connection conn = null;

	int cnt = 0;
	SickVO vo = null;

	public Connection getConn() {

		Connection conn = null;

		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
					+ "database=SMARTLIB;user=importking;password=12345";
			conn = DriverManager.getConnection(connectionUrl);
			Statement stmt = conn.createStatement();
			System.out.println("SickDAO getConn() ���� �Ϸ� -> MS-SQL ���� �Ϸ�");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;
	}

	public void close() {

		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (psmt != null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public int register(String mng_num, String sick_category, String sick_degree, String sick_reg_date,
			String sick_reg_id, String isbn, String libcd, String content) {

		try {

			String sql;
			conn = getConn();

			// Step1) Insert �Ҷ� �ʿ��� �������� �����´�.

			sql = "\r\n" + "  SELECT TOP 1 " + " ID\r\n" + "		, LIB_CD\r\n" + "		, MNG_NO\r\n"
					+ "  FROM MEMBER_BOOK_LOAN\r\n" + "  WHERE 1=1\r\n" + "	AND ID = ?\r\n" + "	AND ISBN = ?";

			psmt = conn.prepareStatement(sql);

			sick_reg_id = "user@naver.com";

			psmt.setString(1, sick_reg_id);
			psmt.setString(2, isbn);

			rs = psmt.executeQuery();

			rs.next();
			libcd = rs.getString(2);
			mng_num = rs.getString(3);

			// Step2) Insert �Ѵ�.
			sql = "insert into Sickness(ISBN, SICK_CATEGORY, SICK_DEGREE, CONTENT, MNG_NUM, SICK_REG_DATE,SICK_REG_ID, LIBCD) "
					+ "values(?,	  ?,			 ?,			  ?,		?,		convert(DATE,GETDATE()),?,		?)";

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, isbn);
			psmt.setString(2, sick_category);
			psmt.setString(3, sick_degree);
			psmt.setString(4, content);
			psmt.setString(5, mng_num);
			psmt.setString(6, sick_reg_id);
			psmt.setString(7, libcd);

			cnt = psmt.executeUpdate();

			if (cnt > 0) {
				System.out.println("Insert �Ϸ�");
			} else {
				System.out.println("Insert ����");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("DAO");
		}
		return cnt;
	}

	public ArrayList<SickVO> apayolist(String sick_reg_id) {

		ArrayList<SickVO> list = new ArrayList<SickVO>();

		try {
			conn = getConn();
			
			sick_reg_id = "user@naver.com";

			String sql = "select * from sickness where sick_reg_id=?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, sick_reg_id);

			rs = psmt.executeQuery(); // ������ �ƴ� �����͸� �ҷ��ö� Result rs

			System.out.println("�˻� ����");

			while (rs.next()) {
				String isbn = rs.getString(1);
				String sick_category = rs.getString(2);
				String sick_degree = rs.getString(3);
				String content = rs.getString(4);
				String mng_num = rs.getString(5);
				String sick_reg_date = rs.getString(6);
				String Libcd = rs.getString(8);
				
				vo = new SickVO(mng_num, sick_category, sick_degree, sick_reg_date, sick_reg_id, isbn, Libcd, content);
				
				list.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}

}
