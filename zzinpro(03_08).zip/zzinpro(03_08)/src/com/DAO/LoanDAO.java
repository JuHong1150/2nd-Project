	package com.DAO;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.ArrayList;

import com.VO.LoanVO;

	public class LoanDAO {

		private PreparedStatement psmt = null;
		private ResultSet rs = null;
		private Connection conn = null;
		
		private int cnt = 0;
		private LoanVO vo = null;
		
		public Connection getConn() {
			
			Connection conn = null;
			
			try {
				
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
	            		+ "database=SMARTLIB;user=importduck;password=12345";
	            //String connectionUrl = "jdbc:sqlserver://localhost;database=SMARTLIB;integratedSecurity=true";
	            conn = DriverManager.getConnection(connectionUrl);
	            Statement stmt = conn.createStatement();
	            System.out.println("LoanDAO getConn() ���� �Ϸ� -> MS-SQL ���� �Ϸ�");
			
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return conn;
		}
		
		public void close() {
			
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (psmt != null) {
				try {
					psmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		public ArrayList<LoanVO> LoanBook(String ID) {
			
			Connection conn = getConn();
			
			ID = "user@naver.com";
			
			ArrayList<LoanVO> arr = new ArrayList<LoanVO>();
			
			System.out.println("��ǪǪǪ������ ���" + ID);
			try {
				String sql = "SELECT    A.ISBN\r\n" + 
						"      , B.BOOK_IMG_URL\r\n" + 
						"FROM MEMBER_BOOK_LOAN      AS A\r\n" + 
						"LEFT JOIN BOOK_IMAGE      AS B\r\n" + 
						"ON 1=1\r\n" + 
						"   AND A.ISBN = B.ISBN\r\n" + 
						"WHERE 1=1\r\n" + 
						"   AND ID = ?\r\n" + 
						"   AND DATEDIFF(DAY,BORROW_YMD,GETDATE()) <= 180\r\n" + 
						"";
				psmt = conn.prepareStatement(sql);
				psmt.setString(1, ID);
				
				rs = psmt.executeQuery();
			    //System.out.println("�������----->>>> " + rs.next());
				while(rs.next()) {
					
					String isbn = rs.getString(1);
					String bookImgUrl = rs.getString(2);
					
					vo = new LoanVO(bookImgUrl, null, isbn, null);
					arr.add(vo);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				close();
			}
			
			return arr;
		}
	}

