import java.sql.*;
import java.sql.SQLException;
// user=MyUserName;password=*****

public class jdbc {

    public static void main(String[] args) throws ClassNotFoundException {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
            		+ "database=SMARTLIB;user=importye;password=12345";
            //String connectionUrl = "jdbc:sqlserver://localhost;database=SMARTLIB;integratedSecurity=true";
            Connection conn = DriverManager.getConnection(connectionUrl);
            Statement stmt = conn.createStatement();
            System.out.println("MS-SQL ���� ���ӿ� �����Ͽ����ϴ�.");
            ResultSet rs = stmt.executeQuery("SELECT TOP 100 ranking, region FROM raw_loanitemsrch_sub");
            while( rs.next() ) {
                   int field1 = rs.getInt("ranking");
                   int field2 = rs.getInt("region");
                   System.out.print(field1 + "\t");
                   System.out.println(field2);
                  }
            rs.close();
            stmt.close();   
            conn.close();
        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

}