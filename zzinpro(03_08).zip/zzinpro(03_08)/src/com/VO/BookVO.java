package com.VO;


public class BookVO {

	private String bookImgUrl;
	private String bookName;
	private String author;
	private String publisher;
	private String isbn;
	private String libCode;
	private String bookGenre;
	
	public BookVO(String libCode, String isbn, String bookName, String author, String publisher, String bookImgUrl) {
		super();
		this.bookName = bookName;
		this.author = author;
		this.publisher = publisher;
		this.isbn = isbn;
		this.libCode = libCode;
		this.bookImgUrl = bookImgUrl;
	}
	
	public BookVO(String libCode, String isbn, String bookName, String author, String publisher, String bookImgUrl, String bookGenre) {
		super();
		this.bookName = bookName;
		this.author = author;
		this.publisher = publisher;
		this.isbn = isbn;
		this.libCode = libCode;
		this.bookImgUrl = bookImgUrl;
		this.bookGenre = bookGenre;
	}
	
	public BookVO(String bookImgUrl) {
	      // TODO Auto-generated constructor stub
	      this.bookImgUrl = bookImgUrl;
    }
	
	public BookVO(String isbn, String bookImgUrl) {
	      // TODO Auto-generated constructor stub
	      this.isbn = isbn;
	      this.bookImgUrl = bookImgUrl;
	}
	
	public String getBookGenre() {
		return bookGenre;
	}

	public void setBookGenre(String bookGenre) {
		this.bookGenre = bookGenre;
	}

	public String getBookImgUrl() {
		return bookImgUrl;
	}

	public void setBookImgUrl(String bookImgUrl) {
		this.bookImgUrl = bookImgUrl;
	}

	public String getLibCode() {
		return libCode;
	}

	public void setLibCode(String libCode) {
		this.libCode = libCode;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
}