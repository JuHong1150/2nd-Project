package com.POJO_MemService;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.MemberDAO;
import com.Inter.Command;
import com.VO.MemberVO;

public class LoginService1 implements Command {
	
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		System.out.println("�α��α���� �����ϰڽ��ϴ�");
		request.setCharacterEncoding("euc-kr");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		MemberDAO dao = new MemberDAO();
		MemberVO vo = dao.Login(id, pw);

		
			HttpSession session = request.getSession();
			session.setAttribute("vo", vo);
		
			
			return "mainPage_login.html";
	}

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		return null;
	}
}
