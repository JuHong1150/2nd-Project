package com.VO;

import java.sql.Date;

public class SickVO {
	private String mng_num;
	private String sick_category;
	private String sick_degree;
	private String sick_reg_date;
	private String sick_reg_id;
	private String isbn;
	private String libcd;
	private String content;

	public SickVO(String mng_num, String sick_category, String sick_degree, String sick_reg_date, String sick_reg_id,
			String isbn, String libcd, String content) {
		super();
		this.mng_num = mng_num;
		this.sick_category = sick_category;
		this.sick_degree = sick_degree;
		this.sick_reg_date = sick_reg_date;
		this.sick_reg_id = sick_reg_id;
		this.isbn = isbn;
		this.libcd = libcd;
		this.content = content;
	}

	public String getMng_num() {
		return mng_num;
	}

	public void setMng_num(String mng_num) {
		this.mng_num = mng_num;
	}

	public String getSick_category() {
		return sick_category;
	}

	public void setSick_category(String sick_category) {
		this.sick_category = sick_category;
	}

	public String getSick_degree() {
		return sick_degree;
	}

	public void setSick_degree(String sick_degree) {
		this.sick_degree = sick_degree;
	}

	public String getSick_reg_date() {
		return sick_reg_date;
	}

	public void setSick_reg_date(String sick_reg_date) {
		this.sick_reg_date = sick_reg_date;
	}

	public String getSick_reg_id() {
		return sick_reg_id;
	}

	public void setSick_reg_id(String sick_reg_id) {
		this.sick_reg_id = sick_reg_id;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getLibcd() {
		return libcd;
	}

	public void setLibcd(String libcd) {
		this.libcd = libcd;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
