package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.VO.BookReservationVO;
import com.VO.MemberVO;

public class BookReservationDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	int cnt = 0;
	MemberVO vo = null;

	public Connection getConn() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionUrl = "jdbc:sqlserver://59.0.236.177;" 
					+ "database=SMARTLIB;user=importking;password=12345";
			conn = DriverManager.getConnection(connectionUrl);
			Statement stmt = conn.createStatement();

		} catch (Exception e) {
			System.out.println("SQLException : " + e);
		}
		return conn;
	}

	public void close() {
		// conn,psmt,rs
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (psmt != null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public ArrayList<BookReservationVO> selectMyBookReservation(String id) {
		BookReservationVO vo = null;

		ArrayList<BookReservationVO> arr = new ArrayList<BookReservationVO>();

		try {
			getConn();

			String sql = "SELECT * FROM MEMBER_BOOK_RESERVE WHERE ID= ?";

			PreparedStatement psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				String LIB_CD = rs.getString(1);
				String ISBN = rs.getString(2);
				String MNG_NO = rs.getString(3);
				String ID = rs.getString(4);
				String RESERVE_YMD = rs.getString(5);
				String RESERVE_SEQ = rs.getString(6);
				String LOAN_HOPE_YMD = rs.getString(7);
		
				// LIB_CD	ISBN	MNG_NO	ID	RESERVE_YMD	RESERVE_SEQ	LOAN_HOPE_YMD
				// sb0001	9791187119845	1	17@naver.com	2021-03-03	1	2021-03-19	
				
				vo = new BookReservationVO(LIB_CD, ISBN, MNG_NO, ID, RESERVE_YMD, RESERVE_SEQ, LOAN_HOPE_YMD);
				arr.add(vo);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return arr;
	}

}
