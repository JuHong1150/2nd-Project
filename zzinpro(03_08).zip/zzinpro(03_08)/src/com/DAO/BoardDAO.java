package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.VO.BoardVO;
import com.VO.BookVO;

public class BoardDAO {
	private PreparedStatement psmt = null;
	private ResultSet rs = null;
	private Connection conn = null;
	
	private int cnt = 0;
	private BoardVO vo = null;
	
	
	
	public Connection getConn() {
	
		try {
			
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://59.0.236.177;"
            		+ "database=SMARTLIB;user=importking;password=12345";
            //String connectionUrl = "jdbc:sqlserver://localhost;database=SMARTLIB;integratedSecurity=true";
            conn = DriverManager.getConnection(connectionUrl);
            Statement stmt = conn.createStatement();
            System.out.println("BookDAO getConn() ���� �Ϸ� -> MS-SQL ���� �Ϸ�");
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public void close() {
		
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (psmt != null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}public ArrayList<BoardVO> select() {
		ArrayList<BoardVO> arr = new ArrayList<BoardVO>();
		try {
			getConn();
			
			String sql ="select * from USER_BOARD";
			PreparedStatement psmt = conn.prepareStatement(sql);
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				String get_id = rs.getString(1);
				String get_title = rs.getString(2);
				int get_category = rs.getInt(3);
				String get_YMD = rs.getString(4);
				
				vo = new BoardVO(get_id,get_title,get_category,get_YMD);
				arr.add(vo);
						}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return arr;
	}
}
